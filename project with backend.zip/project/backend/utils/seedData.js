const mongoose = require('mongoose');
const User = require('../models/User');
const Branch = require('../models/Branch');
const Club = require('../models/Club');
const Announcement = require('../models/Announcement');
require('dotenv').config();

const seedData = async () => {
  try {
    // Connect to database
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/dbu-student-council');
    console.log('Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Branch.deleteMany({});
    await Club.deleteMany({});
    await Announcement.deleteMany({});
    console.log('Cleared existing data');

    // Create branches
    const branches = await Branch.create([
      {
        name: 'Clubs and Associations',
        nameAmharic: 'ክበባት እና ማህበራት',
        description: 'Student clubs and associations management',
        responsibilities: ['Club registration', 'Event coordination', 'Inter-club competitions'],
        contactEmail: 'clubs@dbu.edu.et',
        contactPhone: '+251-11-681-1010'
      },
      {
        name: 'Academic Affairs',
        nameAmharic: 'የትምህርት ጉዳዮች',
        description: 'Academic programs and curriculum oversight',
        responsibilities: ['Curriculum review', 'Academic policy', 'Student-faculty liaison'],
        contactEmail: 'academic@dbu.edu.et',
        contactPhone: '+251-11-681-1011'
      },
      {
        name: 'Student Services',
        nameAmharic: 'የተማሪ አገልግሎቶች',
        description: 'Student support and welfare services',
        responsibilities: ['Housing', 'Health services', 'Financial aid'],
        contactEmail: 'services@dbu.edu.et',
        contactPhone: '+251-11-681-1012'
      }
    ]);

    console.log('Created branches');

    // Create users
    const users = await User.create([
      {
        firstName: 'Super',
        lastName: 'Admin',
        email: 'admin@dbu.edu.et',
        password: 'password',
        phone: '+251911234567',
        role: 'super-admin'
      },
      {
        firstName: 'Branch',
        lastName: 'Admin',
        email: 'clubs.admin@dbu.edu.et',
        password: 'password',
        phone: '+251911234568',
        role: 'branch-admin',
        branch: branches[0]._id
      },
      {
        firstName: 'John',
        lastName: 'Doe',
        email: 'john.doe@student.dbu.edu.et',
        password: 'password',
        phone: '+251911234569',
        role: 'student',
        studentId: 'DBU/CS/2021/001',
        department: 'Computer Science',
        year: '3rd Year'
      },
      {
        firstName: 'Jane',
        lastName: 'Smith',
        email: 'jane.smith@student.dbu.edu.et',
        password: 'password',
        phone: '+251911234570',
        role: 'student',
        studentId: 'DBU/CS/2021/002',
        department: 'Computer Science',
        year: '3rd Year'
      }
    ]);

    console.log('Created users');

    // Update branch admin
    branches[0].admin = users[1]._id;
    await branches[0].save();

    // Create clubs
    const clubs = await Club.create([
      {
        name: 'Computer Science Club',
        description: 'A community for CS students to collaborate, learn, and build innovative projects together.',
        branch: branches[0]._id,
        president: users[2]._id,
        members: [
          { user: users[2]._id, role: 'officer' },
          { user: users[3]._id, role: 'member' }
        ],
        status: 'approved',
        approvedBy: users[1]._id,
        approvedAt: new Date()
      },
      {
        name: 'Engineering Society',
        description: 'Promoting engineering excellence through workshops, competitions, and industry connections.',
        branch: branches[0]._id,
        president: users[3]._id,
        members: [
          { user: users[3]._id, role: 'officer' }
        ],
        status: 'pending'
      }
    ]);

    console.log('Created clubs');

    // Create announcements
    await Announcement.create([
      {
        title: 'New Student Orientation Week',
        content: 'Welcome new students! Join us for orientation activities from March 1-7, 2024. Get to know your campus, meet fellow students, and learn about available resources.',
        category: 'general',
        priority: 'high',
        author: users[1]._id,
        branch: branches[0]._id,
        isPublished: true,
        publishedAt: new Date(),
        image: 'https://images.pexels.com/photos/1454360/pexels-photo-1454360.jpeg'
      },
      {
        title: 'Student Council Elections 2024',
        content: 'Nominations are now open for Student Council positions. Be the change you want to see! Submit your candidacy and help shape the future of student life at DBU.',
        category: 'elections',
        priority: 'high',
        author: users[0]._id,
        isPublished: true,
        publishedAt: new Date(),
        image: 'https://images.pexels.com/photos/1181406/pexels-photo-1181406.jpeg'
      }
    ]);

    console.log('Created announcements');
    console.log('✅ Seed data created successfully!');
    
    console.log('\n📧 Test Accounts:');
    console.log('Super Admin: admin@dbu.edu.et / password');
    console.log('Branch Admin: clubs.admin@dbu.edu.et / password');
    console.log('Student 1: john.doe@student.dbu.edu.et / password');
    console.log('Student 2: jane.smith@student.dbu.edu.et / password');

  } catch (error) {
    console.error('❌ Seed error:', error);
  } finally {
    mongoose.connection.close();
  }
};

// Run if called directly
if (require.main === module) {
  seedData();
}

module.exports = seedData;