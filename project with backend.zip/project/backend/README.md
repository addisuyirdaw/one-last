# DBU Student Council Backend API

A comprehensive Node.js + Express + MongoDB backend for the DBU Student Council website.

## 🚀 Features

- **Authentication & Authorization** - JWT-based auth with role-based access control
- **User Management** - Students, branch admins, and super admins
- **Club Management** - Registration, approval, membership management
- **Elections System** - Create elections, candidate registration, voting
- **Complaints System** - Submit, track, and resolve student complaints
- **Announcements** - Create and manage campus announcements
- **Branch Management** - Organize student council departments

## 🛠️ Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT (JSON Web Tokens)
- **Validation**: Express Validator
- **Security**: Helmet, CORS, Rate Limiting
- **File Upload**: Multer
- **Email**: Nodemailer

## 📁 Project Structure

```
backend/
├── models/           # MongoDB schemas
├── routes/           # API route handlers
├── middleware/       # Custom middleware (auth, validation)
├── utils/           # Utility functions and seed data
├── uploads/         # File upload directory
├── server.js        # Main server file
└── package.json     # Dependencies and scripts
```

## 🔧 Setup Instructions

### 1. Environment Variables

Create a `.env` file in the backend directory:

```env
# Database
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/dbu-student-council

# JWT Secret (use a strong, random string)
JWT_SECRET=your-super-secret-jwt-key-here

# Frontend URL
FRONTEND_URL=http://localhost:5173

# Email Configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password

# Environment
NODE_ENV=development
```

### 2. Install Dependencies

```bash
cd backend
npm install
```

### 3. Seed Database (Optional)

```bash
node utils/seedData.js
```

### 4. Start Server

```bash
# Development
npm run dev

# Production
npm start
```

## 📚 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user
- `POST /api/auth/logout` - Logout user
- `POST /api/auth/change-password` - Change password

### Users
- `GET /api/users` - Get all users (Admin)
- `PUT /api/users/:id/role` - Update user role (Super Admin)

### Clubs
- `GET /api/clubs` - Get all clubs
- `GET /api/clubs/:id` - Get single club
- `POST /api/clubs` - Create new club (Student)
- `PUT /api/clubs/:id` - Update club (President/Admin)
- `POST /api/clubs/:id/join` - Join club (Student)
- `POST /api/clubs/:id/leave` - Leave club (Student)
- `PUT /api/clubs/:id/approve` - Approve/reject club (Admin)
- `DELETE /api/clubs/:id` - Delete club (Admin)

### Elections
- `GET /api/elections` - Get all elections
- `POST /api/elections` - Create election (Admin)
- `POST /api/elections/:id/register` - Register as candidate (Student)
- `POST /api/elections/:id/vote` - Cast vote (Student)

### Complaints
- `GET /api/complaints` - Get complaints (filtered by role)
- `POST /api/complaints` - Submit complaint (Student)
- `POST /api/complaints/:id/respond` - Add response (Admin)
- `PUT /api/complaints/:id/status` - Update status (Admin)

### Announcements
- `GET /api/announcements` - Get published announcements
- `POST /api/announcements` - Create announcement (Admin)
- `PUT /api/announcements/:id/publish` - Publish announcement (Admin)

### Branches
- `GET /api/branches` - Get all branches
- `POST /api/branches` - Create branch (Super Admin)

## 🔐 Authentication

The API uses JWT tokens for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

## 👥 User Roles

- **Student**: Can register for clubs, vote in elections, submit complaints
- **Branch Admin**: Can manage clubs in their branch, respond to complaints
- **Super Admin**: Full access to all features and user management

## 🧪 Test Accounts

After running the seed script, you can use these test accounts:

- **Super Admin**: `admin@dbu.edu.et` / `password`
- **Branch Admin**: `clubs.admin@dbu.edu.et` / `password`
- **Student 1**: `john.doe@student.dbu.edu.et` / `password`
- **Student 2**: `jane.smith@student.dbu.edu.et` / `password`

## 🚀 Deployment

### MongoDB Atlas Setup
1. Create account at [MongoDB Atlas](https://www.mongodb.com/atlas)
2. Create a new cluster
3. Get connection string and add to `.env`

### Hosting Options
- **Render**: Easy deployment with free tier
- **Railway**: Modern platform with great DX
- **Heroku**: Classic platform (paid plans only)

## 📝 API Documentation

For detailed API documentation with request/response examples, you can:
1. Import the Postman collection (coming soon)
2. Use the built-in health check: `GET /api/health`
3. Check the route files for detailed parameter information

## 🔒 Security Features

- Password hashing with bcrypt
- JWT token authentication
- Rate limiting to prevent abuse
- CORS configuration
- Input validation and sanitization
- Helmet for security headers
- Role-based access control

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.