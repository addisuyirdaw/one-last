const express = require('express');
const { body, validationResult } = require('express-validator');
const Election = require('../models/Election');
const User = require('../models/User');
const { authenticateToken, requireAdmin, requireStudent } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/elections
// @desc    Get all elections
// @access  Public
router.get('/', async (req, res) => {
  try {
    const { 
      status, 
      position, 
      page = 1, 
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;

    const filter = {};
    if (status) filter.status = status;
    if (position) filter.position = position;

    const skip = (page - 1) * limit;
    const sortOptions = { [sortBy]: sortOrder === 'desc' ? -1 : 1 };

    const elections = await Election.find(filter)
      .populate('createdBy', 'firstName lastName')
      .populate('candidates.user', 'firstName lastName email department')
      .populate('winner', 'firstName lastName')
      .sort(sortOptions)
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Election.countDocuments(filter);

    res.json({
      elections,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (error) {
    console.error('Get elections error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/elections
// @desc    Create new election
// @access  Private (Admin)
router.post('/', [
  authenticateToken,
  requireAdmin,
  body('title').trim().isLength({ min: 5, max: 200 }).withMessage('Title must be 5-200 characters'),
  body('description').trim().isLength({ min: 10, max: 1000 }).withMessage('Description must be 10-1000 characters'),
  body('position').isIn([
    'Student Council President',
    'Vice President', 
    'Secretary General',
    'Treasurer',
    'Academic Affairs Director',
    'Sports Director',
    'Cultural Affairs Director',
    'Department Representative'
  ]).withMessage('Invalid position'),
  body('candidateRegistrationStart').isISO8601().withMessage('Valid start date required'),
  body('candidateRegistrationEnd').isISO8601().withMessage('Valid end date required'),
  body('votingStart').isISO8601().withMessage('Valid voting start date required'),
  body('votingEnd').isISO8601().withMessage('Valid voting end date required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const election = new Election({
      ...req.body,
      createdBy: req.user._id
    });

    await election.save();
    await election.populate('createdBy', 'firstName lastName');

    res.status(201).json({
      message: 'Election created successfully',
      election
    });
  } catch (error) {
    console.error('Create election error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/elections/:id/register
// @desc    Register as candidate
// @access  Private (Students)
router.post('/:id/register', [
  authenticateToken,
  requireStudent,
  body('manifesto').trim().isLength({ min: 50, max: 2000 }).withMessage('Manifesto must be 50-2000 characters')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const election = await Election.findById(req.params.id);
    if (!election) {
      return res.status(404).json({ message: 'Election not found' });
    }

    // Check if registration is open
    const now = new Date();
    if (now < election.candidateRegistrationStart || now > election.candidateRegistrationEnd) {
      return res.status(400).json({ message: 'Candidate registration is not open' });
    }

    // Check if already registered
    const existingCandidate = election.candidates.find(candidate => 
      candidate.user.toString() === req.user._id.toString()
    );

    if (existingCandidate) {
      return res.status(400).json({ message: 'Already registered as candidate' });
    }

    // Add candidate
    election.candidates.push({
      user: req.user._id,
      manifesto: req.body.manifesto,
      photo: req.body.photo
    });

    await election.save();

    res.json({ message: 'Successfully registered as candidate' });
  } catch (error) {
    console.error('Register candidate error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/elections/:id/vote
// @desc    Cast vote
// @access  Private (Students)
router.post('/:id/vote', [
  authenticateToken,
  requireStudent,
  body('candidateId').isMongoId().withMessage('Valid candidate ID required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const election = await Election.findById(req.params.id);
    if (!election) {
      return res.status(404).json({ message: 'Election not found' });
    }

    // Check if voting is open
    const now = new Date();
    if (now < election.votingStart || now > election.votingEnd) {
      return res.status(400).json({ message: 'Voting is not open' });
    }

    // Check if already voted
    const existingVote = election.votes.find(vote => 
      vote.voter.toString() === req.user._id.toString()
    );

    if (existingVote && !election.allowMultipleVotes) {
      return res.status(400).json({ message: 'You have already voted' });
    }

    // Find candidate
    const candidate = election.candidates.id(req.body.candidateId);
    if (!candidate) {
      return res.status(404).json({ message: 'Candidate not found' });
    }

    // Cast vote
    candidate.votes += 1;
    election.votes.push({
      voter: req.user._id,
      candidate: req.body.candidateId
    });
    election.totalVotes += 1;

    await election.save();

    res.json({ message: 'Vote cast successfully' });
  } catch (error) {
    console.error('Cast vote error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;