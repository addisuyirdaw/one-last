const express = require('express');
const { body, validationResult } = require('express-validator');
const Complaint = require('../models/Complaint');
const { authenticateToken, requireAdmin, requireStudent } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/complaints
// @desc    Get complaints (filtered by user role)
// @access  Private
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { 
      status, 
      category, 
      priority,
      page = 1, 
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;

    const filter = {};
    
    // Students can only see their own complaints
    if (req.user.role === 'student') {
      filter.submittedBy = req.user._id;
    }
    
    if (status) filter.status = status;
    if (category) filter.category = category;
    if (priority) filter.priority = priority;

    const skip = (page - 1) * limit;
    const sortOptions = { [sortBy]: sortOrder === 'desc' ? -1 : 1 };

    const complaints = await Complaint.find(filter)
      .populate('submittedBy', 'firstName lastName email')
      .populate('assignedTo', 'firstName lastName')
      .populate('assignedBranch', 'name')
      .populate('responses.respondedBy', 'firstName lastName')
      .sort(sortOptions)
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Complaint.countDocuments(filter);

    res.json({
      complaints,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (error) {
    console.error('Get complaints error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/complaints
// @desc    Submit new complaint
// @access  Private (Students)
router.post('/', [
  authenticateToken,
  requireStudent,
  body('title').trim().isLength({ min: 5, max: 200 }).withMessage('Title must be 5-200 characters'),
  body('description').trim().isLength({ min: 20, max: 2000 }).withMessage('Description must be 20-2000 characters'),
  body('category').isIn([
    'academic', 'accommodation', 'dining', 'transportation', 'facilities',
    'discrimination', 'harassment', 'financial', 'health-services', 'library',
    'technology', 'other'
  ]).withMessage('Invalid category')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const complaint = new Complaint({
      ...req.body,
      submittedBy: req.user._id
    });

    await complaint.save();
    await complaint.populate('submittedBy', 'firstName lastName email');

    res.status(201).json({
      message: 'Complaint submitted successfully',
      complaint
    });
  } catch (error) {
    console.error('Submit complaint error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/complaints/:id/respond
// @desc    Add response to complaint
// @access  Private (Admin)
router.post('/:id/respond', [
  authenticateToken,
  requireAdmin,
  body('message').trim().isLength({ min: 10, max: 1000 }).withMessage('Response must be 10-1000 characters')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    complaint.responses.push({
      message: req.body.message,
      respondedBy: req.user._id,
      isPublic: req.body.isPublic !== false
    });

    // Update status if this is the first response
    if (complaint.status === 'submitted') {
      complaint.status = 'under-review';
    }

    await complaint.save();
    await complaint.populate('responses.respondedBy', 'firstName lastName');

    res.json({
      message: 'Response added successfully',
      complaint
    });
  } catch (error) {
    console.error('Add response error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/complaints/:id/status
// @desc    Update complaint status
// @access  Private (Admin)
router.put('/:id/status', [
  authenticateToken,
  requireAdmin,
  body('status').isIn([
    'submitted', 'under-review', 'in-progress', 'resolved', 'closed', 'rejected'
  ]).withMessage('Invalid status')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    const oldStatus = complaint.status;
    complaint.status = req.body.status;

    if (req.body.status === 'resolved' && !complaint.actualResolutionDate) {
      complaint.actualResolutionDate = new Date();
    }

    // Add system response for status change
    complaint.responses.push({
      message: `Status changed from "${oldStatus}" to "${req.body.status}"`,
      respondedBy: req.user._id,
      isPublic: false
    });

    await complaint.save();

    res.json({
      message: 'Status updated successfully',
      complaint
    });
  } catch (error) {
    console.error('Update status error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;