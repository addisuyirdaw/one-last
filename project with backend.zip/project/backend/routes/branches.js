const express = require('express');
const { body, validationResult } = require('express-validator');
const Branch = require('../models/Branch');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/branches
// @desc    Get all branches
// @access  Public
router.get('/', async (req, res) => {
  try {
    const branches = await Branch.find({ isActive: true })
      .populate('admin', 'firstName lastName email')
      .populate('members.user', 'firstName lastName')
      .sort({ name: 1 });

    res.json({ branches });
  } catch (error) {
    console.error('Get branches error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/branches
// @desc    Create new branch
// @access  Private (Super Admin)
router.post('/', [
  authenticateToken,
  requireAdmin,
  body('name').trim().isLength({ min: 3, max: 100 }).withMessage('Name must be 3-100 characters'),
  body('nameAmharic').trim().isLength({ min: 3, max: 100 }).withMessage('Amharic name must be 3-100 characters'),
  body('description').trim().isLength({ min: 10, max: 500 }).withMessage('Description must be 10-500 characters')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const branch = new Branch(req.body);
    await branch.save();

    res.status(201).json({
      message: 'Branch created successfully',
      branch
    });
  } catch (error) {
    console.error('Create branch error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;