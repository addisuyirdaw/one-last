const express = require('express');
const { body, validationResult } = require('express-validator');
const Club = require('../models/Club');
const User = require('../models/User');
const Branch = require('../models/Branch');
const { authenticateToken, requireAdmin, requireStudent } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/clubs
// @desc    Get all clubs with filtering
// @access  Public
router.get('/', async (req, res) => {
  try {
    const { 
      status, 
      branch, 
      search, 
      page = 1, 
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;

    // Build filter object
    const filter = {};
    
    if (status) filter.status = status;
    if (branch) filter.branch = branch;
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    // Calculate pagination
    const skip = (page - 1) * limit;
    const sortOptions = { [sortBy]: sortOrder === 'desc' ? -1 : 1 };

    // Get clubs with population
    const clubs = await Club.find(filter)
      .populate('branch', 'name nameAmharic')
      .populate('president', 'firstName lastName email')
      .populate('members.user', 'firstName lastName')
      .sort(sortOptions)
      .skip(skip)
      .limit(parseInt(limit));

    // Get total count for pagination
    const total = await Club.countDocuments(filter);

    res.json({
      clubs,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total,
        hasNext: page * limit < total,
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.error('Get clubs error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/clubs/:id
// @desc    Get single club by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const club = await Club.findById(req.params.id)
      .populate('branch', 'name nameAmharic description')
      .populate('president vicePresident secretary treasurer', 'firstName lastName email')
      .populate('members.user', 'firstName lastName email department')
      .populate('approvedBy', 'firstName lastName');

    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    res.json({ club });
  } catch (error) {
    console.error('Get club error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/clubs
// @desc    Create new club
// @access  Private (Students)
router.post('/', [
  authenticateToken,
  requireStudent,
  body('name').trim().isLength({ min: 3, max: 100 }).withMessage('Club name must be 3-100 characters'),
  body('description').trim().isLength({ min: 10, max: 1000 }).withMessage('Description must be 10-1000 characters'),
  body('branch').isMongoId().withMessage('Valid branch ID is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const { name, description, branch } = req.body;

    // Check if club name already exists
    const existingClub = await Club.findOne({ name });
    if (existingClub) {
      return res.status(400).json({ message: 'Club with this name already exists' });
    }

    // Verify branch exists
    const branchExists = await Branch.findById(branch);
    if (!branchExists) {
      return res.status(400).json({ message: 'Invalid branch' });
    }

    // Create new club
    const club = new Club({
      name,
      description,
      branch,
      president: req.user._id,
      members: [{ user: req.user._id, role: 'officer' }]
    });

    await club.save();

    // Populate the response
    await club.populate('branch president members.user');

    res.status(201).json({
      message: 'Club created successfully',
      club
    });
  } catch (error) {
    console.error('Create club error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/clubs/:id
// @desc    Update club
// @access  Private (Club President or Admin)
router.put('/:id', [
  authenticateToken,
  body('name').optional().trim().isLength({ min: 3, max: 100 }),
  body('description').optional().trim().isLength({ min: 10, max: 1000 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const club = await Club.findById(req.params.id);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    // Check permissions
    const isPresident = club.president.toString() === req.user._id.toString();
    const isAdmin = ['branch-admin', 'super-admin'].includes(req.user.role);
    
    if (!isPresident && !isAdmin) {
      return res.status(403).json({ message: 'Not authorized to update this club' });
    }

    // Update allowed fields
    const allowedUpdates = ['name', 'description', 'logo'];
    const updates = {};
    
    allowedUpdates.forEach(field => {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    });

    Object.assign(club, updates);
    await club.save();

    await club.populate('branch president members.user');

    res.json({
      message: 'Club updated successfully',
      club
    });
  } catch (error) {
    console.error('Update club error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/clubs/:id/join
// @desc    Join a club
// @access  Private (Students)
router.post('/:id/join', [authenticateToken, requireStudent], async (req, res) => {
  try {
    const club = await Club.findById(req.params.id);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    if (club.status !== 'approved') {
      return res.status(400).json({ message: 'Cannot join unapproved club' });
    }

    // Check if already a member
    const isMember = club.members.some(member => 
      member.user.toString() === req.user._id.toString()
    );

    if (isMember) {
      return res.status(400).json({ message: 'Already a member of this club' });
    }

    // Add member
    club.members.push({ user: req.user._id, role: 'member' });
    await club.save();

    res.json({ message: 'Successfully joined the club' });
  } catch (error) {
    console.error('Join club error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/clubs/:id/leave
// @desc    Leave a club
// @access  Private (Students)
router.post('/:id/leave', [authenticateToken, requireStudent], async (req, res) => {
  try {
    const club = await Club.findById(req.params.id);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    // Check if user is the president
    if (club.president.toString() === req.user._id.toString()) {
      return res.status(400).json({ 
        message: 'Club president cannot leave. Transfer presidency first.' 
      });
    }

    // Remove member
    club.members = club.members.filter(member => 
      member.user.toString() !== req.user._id.toString()
    );
    
    await club.save();

    res.json({ message: 'Successfully left the club' });
  } catch (error) {
    console.error('Leave club error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/clubs/:id/approve
// @desc    Approve/reject club
// @access  Private (Admin)
router.put('/:id/approve', [
  authenticateToken,
  requireAdmin,
  body('status').isIn(['approved', 'rejected']).withMessage('Status must be approved or rejected'),
  body('rejectionReason').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const { status, rejectionReason } = req.body;
    
    const club = await Club.findById(req.params.id);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    club.status = status;
    club.approvedBy = req.user._id;
    club.approvedAt = new Date();
    
    if (status === 'rejected' && rejectionReason) {
      club.rejectionReason = rejectionReason;
    }

    await club.save();

    res.json({
      message: `Club ${status} successfully`,
      club
    });
  } catch (error) {
    console.error('Approve club error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE /api/clubs/:id
// @desc    Delete club
// @access  Private (Super Admin)
router.delete('/:id', [authenticateToken, requireAdmin], async (req, res) => {
  try {
    const club = await Club.findById(req.params.id);
    if (!club) {
      return res.status(404).json({ message: 'Club not found' });
    }

    await Club.findByIdAndDelete(req.params.id);

    res.json({ message: 'Club deleted successfully' });
  } catch (error) {
    console.error('Delete club error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;