const express = require('express');
const { body, validationResult } = require('express-validator');
const Announcement = require('../models/Announcement');
const { authenticateToken, requireAdmin, optionalAuth } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/announcements
// @desc    Get all published announcements
// @access  Public
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { 
      category, 
      priority,
      page = 1, 
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;

    const filter = { isPublished: true };
    
    if (category) filter.category = category;
    if (priority) filter.priority = priority;

    // Filter by expiration date
    filter.$or = [
      { expiresAt: { $exists: false } },
      { expiresAt: { $gt: new Date() } }
    ];

    const skip = (page - 1) * limit;
    const sortOptions = { isPinned: -1, [sortBy]: sortOrder === 'desc' ? -1 : 1 };

    const announcements = await Announcement.find(filter)
      .populate('author', 'firstName lastName')
      .populate('branch', 'name')
      .sort(sortOptions)
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Announcement.countDocuments(filter);

    res.json({
      announcements,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (error) {
    console.error('Get announcements error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/announcements
// @desc    Create new announcement
// @access  Private (Admin)
router.post('/', [
  authenticateToken,
  requireAdmin,
  body('title').trim().isLength({ min: 5, max: 200 }).withMessage('Title must be 5-200 characters'),
  body('content').trim().isLength({ min: 20, max: 2000 }).withMessage('Content must be 20-2000 characters'),
  body('category').isIn([
    'general', 'academic', 'events', 'elections', 'clubs', 'sports', 'cultural', 'emergency', 'maintenance'
  ]).withMessage('Invalid category')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const announcement = new Announcement({
      ...req.body,
      author: req.user._id,
      branch: req.user.branch
    });

    await announcement.save();
    await announcement.populate('author branch');

    res.status(201).json({
      message: 'Announcement created successfully',
      announcement
    });
  } catch (error) {
    console.error('Create announcement error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/announcements/:id/publish
// @desc    Publish announcement
// @access  Private (Admin)
router.put('/:id/publish', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const announcement = await Announcement.findById(req.params.id);
    if (!announcement) {
      return res.status(404).json({ message: 'Announcement not found' });
    }

    announcement.isPublished = true;
    announcement.publishedAt = new Date();
    await announcement.save();

    res.json({
      message: 'Announcement published successfully',
      announcement
    });
  } catch (error) {
    console.error('Publish announcement error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;