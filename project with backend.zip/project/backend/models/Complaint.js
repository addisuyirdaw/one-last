const mongoose = require('mongoose');

const responseSchema = new mongoose.Schema({
  message: {
    type: String,
    required: true,
    maxlength: [1000, 'Response cannot exceed 1000 characters']
  },
  respondedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  respondedAt: {
    type: Date,
    default: Date.now
  },
  isPublic: {
    type: Boolean,
    default: true
  }
});

const complaintSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Complaint title is required'],
    trim: true,
    maxlength: [200, 'Title cannot exceed 200 characters']
  },
  description: {
    type: String,
    required: [true, 'Complaint description is required'],
    maxlength: [2000, 'Description cannot exceed 2000 characters']
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: [
      'academic',
      'accommodation',
      'dining',
      'transportation',
      'facilities',
      'discrimination',
      'harassment',
      'financial',
      'health-services',
      'library',
      'technology',
      'other'
    ]
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium'
  },
  status: {
    type: String,
    enum: ['submitted', 'under-review', 'in-progress', 'resolved', 'closed', 'rejected'],
    default: 'submitted'
  },
  submittedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  assignedBranch: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Branch'
  },
  responses: [responseSchema],
  attachments: [{
    name: String,
    url: String,
    size: String,
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }],
  isAnonymous: {
    type: Boolean,
    default: false
  },
  isUrgent: {
    type: Boolean,
    default: false
  },
  expectedResolutionDate: {
    type: Date
  },
  actualResolutionDate: {
    type: Date
  },
  satisfactionRating: {
    type: Number,
    min: 1,
    max: 5
  },
  satisfactionFeedback: {
    type: String,
    maxlength: [500, 'Feedback cannot exceed 500 characters']
  },
  tags: [{
    type: String,
    trim: true
  }],
  viewCount: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Pre-save middleware to update updatedAt
complaintSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Method to add response
complaintSchema.methods.addResponse = function(responseData) {
  this.responses.push(responseData);
  
  // Update status if this is the first response
  if (this.status === 'submitted') {
    this.status = 'under-review';
  }
  
  return this.save();
};

// Method to update status
complaintSchema.methods.updateStatus = function(newStatus, userId) {
  this.status = newStatus;
  
  if (newStatus === 'resolved' && !this.actualResolutionDate) {
    this.actualResolutionDate = new Date();
  }
  
  // Add system response for status change
  this.responses.push({
    message: `Status changed to: ${newStatus}`,
    respondedBy: userId,
    isPublic: false
  });
  
  return this.save();
};

// Method to assign complaint
complaintSchema.methods.assignTo = function(userId, branchId) {
  this.assignedTo = userId;
  this.assignedBranch = branchId;
  this.status = 'in-progress';
  
  return this.save();
};

module.exports = mongoose.model('Complaint', complaintSchema);