const mongoose = require('mongoose');

const branchSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Branch name is required'],
    unique: true,
    trim: true,
    maxlength: [100, 'Branch name cannot exceed 100 characters']
  },
  nameAmharic: {
    type: String,
    required: [true, 'Amharic name is required'],
    trim: true,
    maxlength: [100, 'Amharic name cannot exceed 100 characters']
  },
  description: {
    type: String,
    required: [true, 'Branch description is required'],
    maxlength: [500, 'Description cannot exceed 500 characters']
  },
  admin: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  members: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    role: {
      type: String,
      enum: ['admin', 'member'],
      default: 'member'
    },
    joinedAt: {
      type: Date,
      default: Date.now
    }
  }],
  responsibilities: [{
    type: String,
    trim: true
  }],
  contactEmail: {
    type: String,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
  },
  contactPhone: {
    type: String
  },
  officeLocation: {
    type: String
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Virtual for member count
branchSchema.virtual('memberCount').get(function() {
  return this.members.length;
});

// Pre-save middleware to update updatedAt
branchSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Method to add member
branchSchema.methods.addMember = function(userId, role = 'member') {
  const existingMember = this.members.find(member => 
    member.user.toString() === userId.toString()
  );
  
  if (!existingMember) {
    this.members.push({ user: userId, role });
    return this.save();
  }
  
  throw new Error('User is already a member of this branch');
};

// Method to remove member
branchSchema.methods.removeMember = function(userId) {
  this.members = this.members.filter(member => 
    member.user.toString() !== userId.toString()
  );
  return this.save();
};

module.exports = mongoose.model('Branch', branchSchema);