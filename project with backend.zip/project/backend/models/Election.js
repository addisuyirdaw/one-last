const mongoose = require('mongoose');

const candidateSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  manifesto: {
    type: String,
    required: [true, 'Candidate manifesto is required'],
    maxlength: [2000, 'Manifesto cannot exceed 2000 characters']
  },
  photo: {
    type: String,
    default: null
  },
  votes: {
    type: Number,
    default: 0
  },
  isApproved: {
    type: Boolean,
    default: false
  },
  approvedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  registeredAt: {
    type: Date,
    default: Date.now
  }
});

const voteSchema = new mongoose.Schema({
  voter: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  candidate: {
    type: mongoose.Schema.Types.ObjectId,
    required: true
  },
  votedAt: {
    type: Date,
    default: Date.now
  }
});

const electionSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Election title is required'],
    trim: true,
    maxlength: [200, 'Title cannot exceed 200 characters']
  },
  description: {
    type: String,
    required: [true, 'Election description is required'],
    maxlength: [1000, 'Description cannot exceed 1000 characters']
  },
  position: {
    type: String,
    required: [true, 'Position is required'],
    enum: [
      'Student Council President',
      'Vice President',
      'Secretary General',
      'Treasurer',
      'Academic Affairs Director',
      'Sports Director',
      'Cultural Affairs Director',
      'Department Representative'
    ]
  },
  eligibleVoters: {
    type: String,
    enum: ['all-students', 'specific-department', 'specific-year'],
    default: 'all-students'
  },
  eligibleDepartment: {
    type: String,
    required: function() { return this.eligibleVoters === 'specific-department'; }
  },
  eligibleYear: {
    type: String,
    required: function() { return this.eligibleVoters === 'specific-year'; }
  },
  candidates: [candidateSchema],
  votes: [voteSchema],
  status: {
    type: String,
    enum: ['draft', 'candidate-registration', 'voting', 'completed', 'cancelled'],
    default: 'draft'
  },
  candidateRegistrationStart: {
    type: Date,
    required: true
  },
  candidateRegistrationEnd: {
    type: Date,
    required: true
  },
  votingStart: {
    type: Date,
    required: true
  },
  votingEnd: {
    type: Date,
    required: true
  },
  maxCandidates: {
    type: Number,
    default: 10
  },
  allowMultipleVotes: {
    type: Boolean,
    default: false
  },
  isPublic: {
    type: Boolean,
    default: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  winner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  totalVotes: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Virtual for candidate count
electionSchema.virtual('candidateCount').get(function() {
  return this.candidates.length;
});

// Pre-save middleware to update updatedAt
electionSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Method to add candidate
electionSchema.methods.addCandidate = function(candidateData) {
  if (this.candidates.length >= this.maxCandidates) {
    throw new Error('Maximum number of candidates reached');
  }
  
  const existingCandidate = this.candidates.find(candidate => 
    candidate.user.toString() === candidateData.user.toString()
  );
  
  if (existingCandidate) {
    throw new Error('User is already a candidate in this election');
  }
  
  this.candidates.push(candidateData);
  return this.save();
};

// Method to cast vote
electionSchema.methods.castVote = function(voterId, candidateId) {
  // Check if user already voted
  const existingVote = this.votes.find(vote => 
    vote.voter.toString() === voterId.toString()
  );
  
  if (existingVote && !this.allowMultipleVotes) {
    throw new Error('User has already voted in this election');
  }
  
  // Find candidate and increment vote count
  const candidate = this.candidates.id(candidateId);
  if (!candidate) {
    throw new Error('Candidate not found');
  }
  
  candidate.votes += 1;
  this.votes.push({ voter: voterId, candidate: candidateId });
  this.totalVotes += 1;
  
  return this.save();
};

module.exports = mongoose.model('Election', electionSchema);