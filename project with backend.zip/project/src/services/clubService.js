import { apiClient } from './api';

export const clubService = {
  // Get all clubs with filtering
  async getClubs(filters = {}) {
    try {
      const response = await apiClient.get('/clubs', filters);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch clubs');
    }
  },

  // Get single club by ID
  async getClub(clubId) {
    try {
      const response = await apiClient.get(`/clubs/${clubId}`);
      return response.club;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch club details');
    }
  },

  // Create new club
  async createClub(clubData) {
    try {
      const response = await apiClient.post('/clubs', clubData);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to create club');
    }
  },

  // Update club
  async updateClub(clubId, clubData) {
    try {
      const response = await apiClient.put(`/clubs/${clubId}`, clubData);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to update club');
    }
  },

  // Join club
  async joinClub(clubId) {
    try {
      const response = await apiClient.post(`/clubs/${clubId}/join`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to join club');
    }
  },

  // Leave club
  async leaveClub(clubId) {
    try {
      const response = await apiClient.post(`/clubs/${clubId}/leave`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to leave club');
    }
  },

  // Approve/Reject club (Admin only)
  async approveClub(clubId, status, rejectionReason = '') {
    try {
      const response = await apiClient.put(`/clubs/${clubId}/approve`, {
        status,
        rejectionReason
      });
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to update club status');
    }
  },

  // Delete club (Admin only)
  async deleteClub(clubId) {
    try {
      const response = await apiClient.delete(`/clubs/${clubId}`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to delete club');
    }
  }
};