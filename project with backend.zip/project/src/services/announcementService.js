import { apiClient } from './api';

export const announcementService = {
  // Get all published announcements
  async getAnnouncements(filters = {}) {
    try {
      const response = await apiClient.get('/announcements', filters);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch announcements');
    }
  },

  // Get single announcement
  async getAnnouncement(announcementId) {
    try {
      const response = await apiClient.get(`/announcements/${announcementId}`);
      return response.announcement;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch announcement details');
    }
  },

  // Create new announcement (Admin only)
  async createAnnouncement(announcementData) {
    try {
      const response = await apiClient.post('/announcements', announcementData);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to create announcement');
    }
  },

  // Update announcement (Admin only)
  async updateAnnouncement(announcementId, announcementData) {
    try {
      const response = await apiClient.put(`/announcements/${announcementId}`, announcementData);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to update announcement');
    }
  },

  // Publish announcement (Admin only)
  async publishAnnouncement(announcementId) {
    try {
      const response = await apiClient.put(`/announcements/${announcementId}/publish`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to publish announcement');
    }
  },

  // Delete announcement (Admin only)
  async deleteAnnouncement(announcementId) {
    try {
      const response = await apiClient.delete(`/announcements/${announcementId}`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to delete announcement');
    }
  },

  // Like/Unlike announcement
  async toggleLike(announcementId) {
    try {
      const response = await apiClient.post(`/announcements/${announcementId}/like`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to toggle like');
    }
  }
};