import { apiClient } from './api';

export const electionService = {
  // Get all elections
  async getElections(filters = {}) {
    try {
      const response = await apiClient.get('/elections', filters);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch elections');
    }
  },

  // Get single election
  async getElection(electionId) {
    try {
      const response = await apiClient.get(`/elections/${electionId}`);
      return response.election;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch election details');
    }
  },

  // Create new election (Admin only)
  async createElection(electionData) {
    try {
      const response = await apiClient.post('/elections', electionData);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to create election');
    }
  },

  // Register as candidate
  async registerCandidate(electionId, candidateData) {
    try {
      const response = await apiClient.post(`/elections/${electionId}/register`, candidateData);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to register as candidate');
    }
  },

  // Cast vote
  async castVote(electionId, candidateId) {
    try {
      const response = await apiClient.post(`/elections/${electionId}/vote`, {
        candidateId
      });
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to cast vote');
    }
  },

  // Get election results
  async getElectionResults(electionId) {
    try {
      const response = await apiClient.get(`/elections/${electionId}/results`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch election results');
    }
  }
};