import { apiClient } from './api';

export const authService = {
  // User Registration
  async register(userData) {
    try {
      const response = await apiClient.post('/auth/register', userData);
      
      if (response.token && response.user) {
        // Store user data and token
        const userWithToken = { ...response.user, token: response.token };
        localStorage.setItem('dbu_user', JSON.stringify(userWithToken));
      }
      
      return response;
    } catch (error) {
      throw new Error(error.message || 'Registration failed');
    }
  },

  // User Login
  async login(email, password) {
    try {
      const response = await apiClient.post('/auth/login', { email, password });
      
      if (response.token && response.user) {
        // Store user data and token
        const userWithToken = { ...response.user, token: response.token };
        localStorage.setItem('dbu_user', JSON.stringify(userWithToken));
      }
      
      return response;
    } catch (error) {
      throw new Error(error.message || 'Login failed');
    }
  },

  // Get Current User
  async getCurrentUser() {
    try {
      const response = await apiClient.get('/auth/me');
      return response.user;
    } catch (error) {
      // If token is invalid, clear stored data
      this.logout();
      throw new Error('Session expired');
    }
  },

  // Logout
  logout() {
    localStorage.removeItem('dbu_user');
    return Promise.resolve();
  },

  // Change Password
  async changePassword(currentPassword, newPassword) {
    try {
      const response = await apiClient.post('/auth/change-password', {
        currentPassword,
        newPassword
      });
      return response;
    } catch (error) {
      throw new Error(error.message || 'Password change failed');
    }
  },

  // Check if user is authenticated
  isAuthenticated() {
    const user = localStorage.getItem('dbu_user');
    return !!user;
  },

  // Get stored user data
  getStoredUser() {
    const user = localStorage.getItem('dbu_user');
    return user ? JSON.parse(user) : null;
  }
};