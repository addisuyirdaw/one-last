import { apiClient } from './api';

export const userService = {
  // Get all users (Admin only)
  async getUsers(filters = {}) {
    try {
      const response = await apiClient.get('/users', filters);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch users');
    }
  },

  // Get single user
  async getUser(userId) {
    try {
      const response = await apiClient.get(`/users/${userId}`);
      return response.user;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch user details');
    }
  },

  // Update user profile
  async updateProfile(userId, userData) {
    try {
      const response = await apiClient.put(`/users/${userId}`, userData);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to update profile');
    }
  },

  // Update user role (Super Admin only)
  async updateUserRole(userId, role, branch = null) {
    try {
      const response = await apiClient.put(`/users/${userId}/role`, { role, branch });
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to update user role');
    }
  },

  // Deactivate user (Admin only)
  async deactivateUser(userId) {
    try {
      const response = await apiClient.put(`/users/${userId}/deactivate`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to deactivate user');
    }
  },

  // Activate user (Admin only)
  async activateUser(userId) {
    try {
      const response = await apiClient.put(`/users/${userId}/activate`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to activate user');
    }
  }
};