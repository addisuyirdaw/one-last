import { apiClient } from './api';

export const branchService = {
  // Get all branches
  async getBranches() {
    try {
      const response = await apiClient.get('/branches');
      return response.branches;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch branches');
    }
  },

  // Get single branch
  async getBranch(branchId) {
    try {
      const response = await apiClient.get(`/branches/${branchId}`);
      return response.branch;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch branch details');
    }
  },

  // Create new branch (Super Admin only)
  async createBranch(branchData) {
    try {
      const response = await apiClient.post('/branches', branchData);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to create branch');
    }
  },

  // Update branch (Admin only)
  async updateBranch(branchId, branchData) {
    try {
      const response = await apiClient.put(`/branches/${branchId}`, branchData);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to update branch');
    }
  },

  // Add member to branch (Admin only)
  async addMember(branchId, userId, role = 'member') {
    try {
      const response = await apiClient.post(`/branches/${branchId}/members`, {
        userId,
        role
      });
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to add member to branch');
    }
  },

  // Remove member from branch (Admin only)
  async removeMember(branchId, userId) {
    try {
      const response = await apiClient.delete(`/branches/${branchId}/members/${userId}`);
      return response;
    } catch (error) {
      throw new Error(error.message || 'Failed to remove member from branch');
    }
  }
};