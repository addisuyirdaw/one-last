import React, { useState } from 'react';
import { Users, Mail, Phone, Calendar, FileText, ChevronRight, Building } from 'lucide-react';
import { branches } from '../../data/mockData';

const Branches = () => {
  const [selectedBranch, setSelectedBranch] = useState(null);

  const branchDetails = {
    'Clubs and Associations': {
      head: 'Alemayehu Tadesse',
      email: 'clubs@dbu.edu.et',
      phone: '+251-11-681-1010',
      members: 12,
      activities: [
        'Club registration and approval',
        'Event coordination and support',
        'Inter-club competitions',
        'Annual club fair organization'
      ],
      recentEvents: [
        { date: '2024-02-15', event: 'Annual Club Fair 2024' },
        { date: '2024-02-01', event: 'New Club Orientation' },
        { date: '2024-01-20', event: 'Inter-Club Sports Tournament' }
      ]
    },
    'Academic Affairs': {
      head: 'Hanan Mohammed',
      email: 'academic@dbu.edu.et',
      phone: '+251-11-681-1011',
      members: 8,
      activities: [
        'Curriculum review and feedback',
        'Academic policy advocacy',
        'Student-faculty liaison',
        'Academic resource development'
      ],
      recentEvents: [
        { date: '2024-02-10', event: 'Faculty-Student Forum' },
        { date: '2024-01-25', event: 'Academic Policy Review' },
        { date: '2024-01-15', event: 'Library Resource Meeting' }
      ]
    },
    'Student Services': {
      head: 'Dawit Bekele',
      email: 'services@dbu.edu.et',
      phone: '+251-11-681-1012',
      members: 10,
      activities: [
        'Housing and accommodation',
        'Health and wellness programs',
        'Financial aid assistance',
        'Student support services'
      ],
      recentEvents: [
        { date: '2024-02-12', event: 'Mental Health Awareness Week' },
        { date: '2024-02-05', event: 'Housing Allocation Meeting' },
        { date: '2024-01-30', event: 'Financial Aid Workshop' }
      ]
    },
    'Campus Life': {
      head: 'Meron Assefa',
      email: 'campus@dbu.edu.et',
      phone: '+251-11-681-1013',
      members: 15,
      activities: [
        'Campus events and festivals',
        'Student orientation programs',
        'Community building initiatives',
        'Campus improvement projects'
      ],
      recentEvents: [
        { date: '2024-02-14', event: 'Valentine\'s Day Celebration' },
        { date: '2024-02-08', event: 'New Student Orientation' },
        { date: '2024-01-28', event: 'Campus Beautification Drive' }
      ]
    },
    'Sports and Recreation': {
      head: 'Yohannes Girma',
      email: 'sports@dbu.edu.et',
      phone: '+251-11-681-1014',
      members: 18,
      activities: [
        'Inter-university competitions',
        'Intramural sports leagues',
        'Fitness and wellness programs',
        'Sports facility management'
      ],
      recentEvents: [
        { date: '2024-02-16', event: 'Basketball Championship' },
        { date: '2024-02-03', event: 'Annual Sports Day' },
        { date: '2024-01-22', event: 'Fitness Challenge Launch' }
      ]
    },
    'Cultural Affairs': {
      head: 'Tigist Haile',
      email: 'culture@dbu.edu.et',
      phone: '+251-11-681-1015',
      members: 14,
      activities: [
        'Cultural festivals and celebrations',
        'Traditional arts promotion',
        'International student integration',
        'Heritage preservation projects'
      ],
      recentEvents: [
        { date: '2024-02-11', event: 'Ethiopian Cultural Night' },
        { date: '2024-01-27', event: 'International Food Festival' },
        { date: '2024-01-18', event: 'Traditional Music Workshop' }
      ]
    }
  };

  const handleBranchClick = (branch) => {
    setSelectedBranch(selectedBranch?.id === branch.id ? null : branch);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 text-white py-20">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">
            Council <span className="text-yellow-400">Branches</span>
          </h1>
          <p className="text-xl lg:text-2xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
            Specialized departments working together to serve every aspect of student life at DBU.
          </p>
        </div>
      </section>

      {/* Branches Overview */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Departments</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Each branch focuses on specific areas to ensure comprehensive student support and services.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {branches.map((branch) => {
              const details = branchDetails[branch.name];
              const isSelected = selectedBranch?.id === branch.id;
              
              return (
                <div key={branch.id} className="group">
                  <div
                    onClick={() => handleBranchClick(branch)}
                    className={`bg-white p-8 rounded-2xl shadow-lg border-2 cursor-pointer transition-all duration-300 ${
                      isSelected 
                        ? 'border-blue-500 shadow-xl transform scale-105' 
                        : 'border-gray-100 hover:border-blue-200 hover:shadow-xl'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-6">
                      <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center group-hover:bg-blue-600 transition-colors duration-300">
                        <Building className="w-6 h-6 text-blue-600 group-hover:text-white transition-colors duration-300" />
                      </div>
                      <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${isSelected ? 'rotate-90' : ''}`} />
                    </div>
                    
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{branch.name}</h3>
                    <p className="text-gray-600 text-sm mb-4">{branch.nameAmharic}</p>
                    <p className="text-gray-600 leading-relaxed mb-6">{branch.description}</p>
                    
                    {details && (
                      <div className="space-y-3">
                        <div className="flex items-center text-sm text-gray-500">
                          <Users className="w-4 h-4 mr-2" />
                          <span>{details.members} members</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Mail className="w-4 h-4 mr-2" />
                          <span>{details.email}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Expanded Details */}
                  {isSelected && details && (
                    <div className="mt-4 bg-blue-50 p-8 rounded-2xl border border-blue-200 animate-fadeIn">
                      <div className="grid md:grid-cols-2 gap-8">
                        <div>
                          <h4 className="font-bold text-gray-900 mb-4">Branch Head</h4>
                          <div className="bg-white p-4 rounded-lg mb-6">
                            <p className="font-semibold text-gray-900">{details.head}</p>
                            <div className="flex items-center mt-2 text-sm text-gray-600">
                              <Mail className="w-4 h-4 mr-2" />
                              <span>{details.email}</span>
                            </div>
                            <div className="flex items-center mt-1 text-sm text-gray-600">
                              <Phone className="w-4 h-4 mr-2" />
                              <span>{details.phone}</span>
                            </div>
                          </div>

                          <h4 className="font-bold text-gray-900 mb-4">Key Activities</h4>
                          <ul className="space-y-2">
                            {details.activities.map((activity, index) => (
                              <li key={index} className="flex items-start">
                                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                                <span className="text-gray-600">{activity}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-bold text-gray-900 mb-4">Recent Events</h4>
                          <div className="space-y-4">
                            {details.recentEvents.map((event, index) => (
                              <div key={index} className="bg-white p-4 rounded-lg">
                                <div className="flex items-center mb-2">
                                  <Calendar className="w-4 h-4 text-blue-600 mr-2" />
                                  <span className="text-sm text-gray-500">{event.date}</span>
                                </div>
                                <p className="font-medium text-gray-900">{event.event}</p>
                              </div>
                            ))}
                          </div>

                          <div className="mt-6">
                            <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center">
                              <FileText className="w-4 h-4 mr-2" />
                              View Full Report
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Branch Statistics</h2>
            <p className="text-xl text-gray-600">
              Overview of our collective impact across all departments.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Building className="w-8 h-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">6</div>
              <div className="text-gray-600">Active Branches</div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg text-center">
              <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">77</div>
              <div className="text-gray-600">Total Members</div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg text-center">
              <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">150+</div>
              <div className="text-gray-600">Events This Year</div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg text-center">
              <div className="w-16 h-16 bg-yellow-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">500+</div>
              <div className="text-gray-600">Projects Completed</div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">Join a Branch</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Interested in contributing to student life? Each branch welcomes dedicated students who want to make a difference.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#login"
              className="bg-yellow-500 text-blue-900 px-8 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200"
            >
              Apply Now
            </a>
            <a
              href="#contact"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-700 transition-colors duration-200"
            >
              Learn More
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Branches;