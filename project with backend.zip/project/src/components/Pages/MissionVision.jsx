import React from 'react';
import { Target, Eye, Compass, Star, Users, BookOpen, Globe, Heart } from 'lucide-react';

const MissionVision = () => {
  const objectives = [
    {
      icon: Users,
      title: 'Student Representation',
      description: 'Advocate for student rights and interests in university governance and decision-making processes.'
    },
    {
      icon: BookOpen,
      title: 'Academic Excellence',
      description: 'Support initiatives that enhance the quality of education and academic resources available to students.'
    },
    {
      icon: Heart,
      title: 'Student Welfare',
      description: 'Ensure comprehensive support systems for student health, housing, and overall well-being.'
    },
    {
      icon: Globe,
      title: 'Community Engagement',
      description: 'Foster connections between the university and the broader Debre Birhan community.'
    },
    {
      icon: Star,
      title: 'Leadership Development',
      description: 'Provide opportunities for students to develop leadership skills and civic responsibility.'
    },
    {
      icon: Compass,
      title: 'Innovation & Progress',
      description: 'Drive technological advancement and modern solutions for campus life improvement.'
    }
  ];

  const achievements = [
    {
      year: '2023',
      title: 'Digital Transformation',
      description: 'Launched comprehensive online platform for elections, club management, and student services.'
    },
    {
      year: '2022',
      title: 'Mental Health Initiative',
      description: 'Established campus counseling services and mental health awareness programs.'
    },
    {
      year: '2021',
      title: 'Infrastructure Improvements',
      description: 'Successfully advocated for new library facilities and upgraded dormitory conditions.'
    },
    {
      year: '2020',
      title: 'COVID-19 Response',
      description: 'Coordinated emergency support systems and remote learning assistance for students.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 text-white py-20">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">
            Mission & <span className="text-yellow-400">Vision</span>
          </h1>
          <p className="text-xl lg:text-2xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
            Guiding principles that drive our commitment to student excellence and community development.
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mr-4">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">Our Mission</h2>
              </div>
              <div className="space-y-6 text-gray-600 leading-relaxed text-lg">
                <p>
                  To serve as the unified voice of Debre Birhan University students, advocating for 
                  their academic, social, and personal development while fostering a vibrant campus 
                  community that promotes excellence, diversity, and innovation.
                </p>
                <p>
                  We are committed to bridging the gap between students and university administration, 
                  ensuring that every student has access to quality education, comprehensive support 
                  services, and opportunities for leadership and personal growth.
                </p>
                <p>
                  Through transparent governance, inclusive representation, and collaborative 
                  partnerships, we strive to create an environment where every student can thrive 
                  academically and personally.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1454360/pexels-photo-1454360.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&dpr=2"
                alt="Students collaborating"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -top-6 -left-6 w-32 h-32 bg-blue-400 rounded-2xl opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="lg:order-2">
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-yellow-500 rounded-2xl flex items-center justify-center mr-4">
                  <Eye className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">Our Vision</h2>
              </div>
              <div className="space-y-6 text-gray-600 leading-relaxed text-lg">
                <p>
                  To be recognized as a model student government that exemplifies democratic 
                  leadership, academic excellence, and social responsibility, inspiring positive 
                  change within our university and the broader Ethiopian higher education landscape.
                </p>
                <p>
                  We envision a future where DBU students are empowered leaders, critical thinkers, 
                  and engaged citizens who contribute meaningfully to their communities and the 
                  nation's development.
                </p>
                <p>
                  Our vision encompasses a digitally advanced, inclusive, and sustainable campus 
                  environment that nurtures innovation, celebrates diversity, and prepares students 
                  for global citizenship.
                </p>
              </div>
            </div>
            <div className="lg:order-1 relative">
              <img
                src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&dpr=2"
                alt="Vision for the future"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-yellow-400 rounded-2xl opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Objectives Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Strategic Objectives</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Key areas of focus that guide our initiatives and programs throughout the academic year.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {objectives.map((objective, index) => (
              <div key={index} className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 group hover:border-blue-200">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors duration-300">
                  <objective.icon className="w-6 h-6 text-blue-600 group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{objective.title}</h3>
                <p className="text-gray-600 leading-relaxed">{objective.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements Timeline */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Recent Achievements</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Milestones that demonstrate our commitment to continuous improvement and student success.
            </p>
          </div>
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-blue-200 hidden lg:block"></div>
            
            <div className="space-y-12">
              {achievements.map((achievement, index) => (
                <div key={index} className={`flex items-center ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'}`}>
                  <div className={`w-full lg:w-5/12 ${index % 2 === 0 ? 'lg:pr-8' : 'lg:pl-8'}`}>
                    <div className="bg-white p-8 rounded-2xl shadow-lg">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold mr-4">
                          {achievement.year}
                        </div>
                        <h3 className="text-xl font-bold text-gray-900">{achievement.title}</h3>
                      </div>
                      <p className="text-gray-600 leading-relaxed">{achievement.description}</p>
                    </div>
                  </div>
                  
                  {/* Timeline dot */}
                  <div className="hidden lg:flex w-2/12 justify-center">
                    <div className="w-4 h-4 bg-blue-600 rounded-full border-4 border-white shadow-lg"></div>
                  </div>
                  
                  <div className="hidden lg:block w-5/12"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">Join Our Mission</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Be part of the change you want to see. Together, we can build a better future for all DBU students.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#login"
              className="bg-yellow-500 text-blue-900 px-8 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200"
            >
              Get Involved
            </a>
            <a
              href="#contact"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-700 transition-colors duration-200"
            >
              Contact Leadership
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default MissionVision;