import React from 'react';
import { Users, Target, Eye, Heart, Award, BookOpen } from 'lucide-react';

const About = () => {
  const stats = [
    { number: '15,000+', label: 'Students', icon: Users },
    { number: '50+', label: 'Active Clubs', icon: Target },
    { number: '100+', label: 'Events/Year', icon: Award },
    { number: '25+', label: 'Years of Excellence', icon: BookOpen },
  ];

  const values = [
    {
      icon: Heart,
      title: 'Student-Centered',
      description: 'Every decision we make prioritizes student welfare and academic success.'
    },
    {
      icon: Users,
      title: 'Inclusive Community',
      description: 'We celebrate diversity and ensure every voice is heard and valued.'
    },
    {
      icon: Target,
      title: 'Excellence',
      description: 'We strive for the highest standards in education and student services.'
    },
    {
      icon: Eye,
      title: 'Transparency',
      description: 'Open communication and accountability in all our operations.'
    }
  ];

  const leadership = [
    {
      name: 'Alemayehu Tadesse',
      position: 'Student Council President',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2',
      bio: 'Computer Science student passionate about technology and student advocacy.'
    },
    {
      name: 'Hanan Mohammed',
      position: 'Vice President',
      image: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2',
      bio: 'Business Administration student focused on organizational development.'
    },
    {
      name: 'Dawit Bekele',
      position: 'Secretary General',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2',
      bio: 'Engineering student committed to improving campus infrastructure.'
    },
    {
      name: 'Meron Assefa',
      position: 'Treasurer',
      image: 'https://images.pexels.com/photos/3763152/pexels-photo-3763152.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2',
      bio: 'Economics student ensuring transparent financial management.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 text-white py-20">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">
            About <span className="text-yellow-400">DBU Student Council</span>
          </h1>
          <p className="text-xl lg:text-2xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
            Empowering students, fostering excellence, and building a vibrant campus community 
            at Debre Birhan University since 1999.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl lg:text-4xl font-bold text-gray-900 mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">Our Story</h2>
              <div className="space-y-6 text-gray-600 leading-relaxed">
                <p>
                  Founded alongside Debre Birhan University in 1999, the Student Council has been 
                  the voice of students for over two decades. What started as a small group of 
                  passionate students has grown into a comprehensive organization serving thousands.
                </p>
                <p>
                  We've evolved from organizing simple campus events to managing complex digital 
                  systems for elections, club management, and student services. Our commitment 
                  to innovation and student welfare remains unwavering.
                </p>
                <p>
                  Today, we're proud to represent one of Ethiopia's most diverse and dynamic 
                  student bodies, fostering leadership, academic excellence, and community engagement.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1454360/pexels-photo-1454360.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&dpr=2"
                alt="DBU Campus"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-yellow-400 rounded-2xl opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The principles that guide everything we do and every decision we make.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-6">
                  <value.icon className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Leadership Team</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Meet the dedicated students leading our council and representing your interests.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {leadership.map((leader, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6">
                  <img
                    src={leader.image}
                    alt={leader.name}
                    className="w-48 h-48 rounded-2xl mx-auto object-cover shadow-lg group-hover:shadow-xl transition-shadow duration-300"
                  />
                  <div className="absolute inset-0 bg-blue-600 opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity duration-300"></div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{leader.name}</h3>
                <p className="text-blue-600 font-semibold mb-3">{leader.position}</p>
                <p className="text-gray-600 text-sm leading-relaxed">{leader.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">Get Involved</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Your voice matters. Join us in shaping the future of student life at DBU.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#clubs"
              className="bg-yellow-500 text-blue-900 px-8 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200"
            >
              Join a Club
            </a>
            <a
              href="#contact"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-700 transition-colors duration-200"
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;