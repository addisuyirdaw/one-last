import React, { useState, useEffect } from 'react';
import { Search, Filter, Plus } from 'lucide-react';
import ClubCard from './ClubCard';
import { usePaginatedApi } from '../../hooks/useApi';
import { clubService } from '../../services/clubService';
import { branchService } from '../../services/branchService';
import { useAuth } from '../../context/AuthContext';

const ClubsSection = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBranch, setSelectedBranch] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedClub, setSelectedClub] = useState(null);
  const [branches, setBranches] = useState([]);

  // Fetch clubs with pagination and filtering
  const {
    data: clubs,
    loading,
    error,
    updateFilters,
    refetch
  } = usePaginatedApi(clubService.getClubs, {
    search: searchTerm,
    branch: selectedBranch !== 'all' ? selectedBranch : undefined,
    status: selectedStatus !== 'all' ? selectedStatus : undefined
  });

  // Fetch branches for filter dropdown
  useEffect(() => {
    const fetchBranches = async () => {
      try {
        const branchData = await branchService.getBranches();
        setBranches(branchData);
      } catch (error) {
        console.error('Failed to fetch branches:', error);
      }
    };
    fetchBranches();
  }, []);

  // Update filters when search/filter values change
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      updateFilters({
        search: searchTerm || undefined,
        branch: selectedBranch !== 'all' ? selectedBranch : undefined,
        status: selectedStatus !== 'all' ? selectedStatus : undefined
      });
    }, 500); // Debounce search

    return () => clearTimeout(timeoutId);
  }, [searchTerm, selectedBranch, selectedStatus, updateFilters]);

  const handleViewDetails = (club) => {
    setSelectedClub(club);
  };

  return (
        <div>
        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            {loading ? 'Loading...' : `Showing ${clubs.length} clubs`}
          </p>
        </div>

        {/* Error State */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700">Error: {error}</p>
            <button 
              onClick={refetch}
              className="mt-2 text-red-600 hover:text-red-700 font-medium"
            >
              Try Again
            </button>
          </div>
        )}

        {/* Clubs Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="bg-gray-200 rounded-xl h-96 animate-pulse"></div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {clubs.map((club) => (
              <ClubCard
                key={club._id || club.id}
                club={club}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        )}

        {!loading && clubs.length === 0 && !error && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
          </div>
        )}
        </div>
    );
};

export default ClubsSection;