// User types
export const USER_ROLES = {
  SUPER_ADMIN: 'super-admin',
  BRANCH_ADMIN: 'branch-admin',
  STUDENT: 'student'
};

// Club status types
export const CLUB_STATUS = {
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected'
};

// Document types
export const DOCUMENT_TYPES = {
  REPORT: 'report',
  PROPOSAL: 'proposal',
  CONSTITUTION: 'constitution',
  FINANCIAL: 'financial'
};

// Announcement priority types
export const ANNOUNCEMENT_PRIORITY = {
  HIGH: 'high',
  MEDIUM: 'medium',
  LOW: 'low'
};

// Election status types
export const ELECTION_STATUS = {
  UPCOMING: 'upcoming',
  ACTIVE: 'active',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled'
};

// Complaint status types
export const COMPLAINT_STATUS = {
  SUBMITTED: 'submitted',
  IN_PROGRESS: 'in-progress',
  RESOLVED: 'resolved',
  CLOSED: 'closed'
};