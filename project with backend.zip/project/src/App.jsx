import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import Hero from './components/Home/Hero';
import AnnouncementCarousel from './components/Home/AnnouncementCarousel';
import ClubsSection from './components/Clubs/ClubsSection';
import About from './components/Pages/About';
import MissionVision from './components/Pages/MissionVision';
import Contact from './components/Pages/Contact';
import Branches from './components/Pages/Branches';
import LoginPage from './components/Auth/LoginPage';
import Register from './components/Auth/Register';
import StudentDashboard from './components/Dashboard/StudentDashboard';
import AdminDashboard from './components/Dashboard/AdminDashboard';

const AppContent = () => {
  const { user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentView, setCurrentView] = useState('home');

  // Handle hash navigation
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') || 'home';
      
      // Handle dashboard routing based on user role
      if (hash === 'dashboard') {
        if (user) {
          if (user.role === 'student') {
            setCurrentView('student-dashboard');
          } else {
            setCurrentView('admin-dashboard');
          }
        } else {
          setCurrentView('login');
        }
      } else {
        setCurrentView(hash);
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Handle initial load

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [user]);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Dashboard views
  if (currentView === 'student-dashboard' && user && user.role === 'student') {
    return <StudentDashboard />;
  }

  if (currentView === 'admin-dashboard' && user && user.role !== 'student') {
    return <AdminDashboard />;
  }

  // Auth views
  if (currentView === 'login') {
    return <LoginPage />;
  }

  if (currentView === 'register') {
    return <Register />;
  }

  // Page views
  if (currentView === 'about') {
    return (
      <div className="min-h-screen bg-white">
        <Header onMenuToggle={toggleMobileMenu} isMobileMenuOpen={isMobileMenuOpen} />
        <About />
        <Footer />
      </div>
    );
  }

  if (currentView === 'mission-vision') {
    return (
      <div className="min-h-screen bg-white">
        <Header onMenuToggle={toggleMobileMenu} isMobileMenuOpen={isMobileMenuOpen} />
        <MissionVision />
        <Footer />
      </div>
    );
  }

  if (currentView === 'contact') {
    return (
      <div className="min-h-screen bg-white">
        <Header onMenuToggle={toggleMobileMenu} isMobileMenuOpen={isMobileMenuOpen} />
        <Contact />
        <Footer />
      </div>
    );
  }

  if (currentView === 'branches') {
    return (
      <div className="min-h-screen bg-white">
        <Header onMenuToggle={toggleMobileMenu} isMobileMenuOpen={isMobileMenuOpen} />
        <Branches />
        <Footer />
      </div>
    );
  }

  // Default home view
  return (
    <div className="min-h-screen bg-white">
      <Header 
        onMenuToggle={toggleMobileMenu} 
        isMobileMenuOpen={isMobileMenuOpen}
      />
      
      <main>
        <Hero />
        <AnnouncementCarousel />
        <ClubsSection />
      </main>

      <Footer />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;