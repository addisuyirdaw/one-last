import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import Hero from './components/Home/Hero';
import AnnouncementCarousel from './components/Home/AnnouncementCarousel';
import ClubsSection from './components/Clubs/ClubsSection';
import LoginPage from './components/Auth/LoginPage';
import AdminDashboard from './components/Dashboard/AdminDashboard';

const AppContent: React.FC = () => {
  const { user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentView, setCurrentView] = useState('home');

  // Handle hash navigation
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash === '#login') {
        setCurrentView('login');
      } else if (hash === '#dashboard' && user && user.role !== 'student') {
        setCurrentView('dashboard');
      } else {
        setCurrentView('home');
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Handle initial load

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [user]);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  if (currentView === 'dashboard' && user && user.role !== 'student') {
    return <AdminDashboard />;
  }

  if (currentView === 'login') {
    return <LoginPage />;
  }

  return (
    <div className="min-h-screen bg-white">
      <Header 
        onMenuToggle={toggleMobileMenu} 
        isMobileMenuOpen={isMobileMenuOpen}
      />
      
      <main>
        <Hero />
        <AnnouncementCarousel />
        <ClubsSection />
      </main>

      <Footer />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;